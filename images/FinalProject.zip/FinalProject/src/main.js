$('#timepicker').clockpicker({
    placement: 'bottom',
    autoclose: true
});

$('[data-toggle="datepicker"]').datepicker();
